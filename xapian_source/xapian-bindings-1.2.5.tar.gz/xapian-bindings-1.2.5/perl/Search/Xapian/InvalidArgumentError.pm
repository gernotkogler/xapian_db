package Search::Xapian::InvalidArgumentError;

=head1 NAME

Search::Xapian::InvalidArgumentError -  InvalidArgumentError indicates an invalid parameter value was passed to the API.

=head1 DESCRIPTION


=cut
1;
