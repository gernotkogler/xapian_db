package Search::Xapian::NetworkTimeoutError;

=head1 NAME

Search::Xapian::NetworkTimeoutError -  Indicates a timeout expired while communicating with a remote database. 


=head1 DESCRIPTION


=cut
1;
