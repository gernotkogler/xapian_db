package Search::Xapian::InternalError;

=head1 NAME

Search::Xapian::InternalError -  InternalError indicates a runtime problem of some sort. 


=head1 DESCRIPTION


=cut
1;
